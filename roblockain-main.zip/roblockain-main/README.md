# roblockain
🔗 Chaincode for securing robot logfiles
